<?xml version="1.0" encoding="UTF-8"?>
<sch:schema xmlns:sch="http://purl.oclc.org/dsdl/schematron" queryBinding="xslt2">
  <sch:ns prefix="f" uri="http://hl7.org/fhir"/>
  <sch:ns prefix="h" uri="http://www.w3.org/1999/xhtml"/>
  <!-- 
    This file contains just the constraints for the profile CQMComputableMeasure
    It includes the base constraints for the resource as well.
    Because of the way that schematrons and containment work, 
    you may need to use this schematron fragment to build a, 
    single schematron that validates contained resources (if you have any) 
  -->
  <sch:pattern>
    <sch:title>f:Measure</sch:title>
    <sch:rule context="f:Measure">
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/uv/cqm/StructureDefinition/cqm-scoringUnit|2.0.0']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/uv/cqm/StructureDefinition/cqm-scoringUnit|2.0.0': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-effectiveDataRequirements|2.0.0']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-effectiveDataRequirements|2.0.0': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/uv/cqm/StructureDefinition/cqm-scoringPrecision|2.0.0']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/uv/cqm/StructureDefinition/cqm-scoringPrecision|2.0.0': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/uv/cqm/StructureDefinition/cqm-reportingTiming|2.0.0']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/uv/cqm/StructureDefinition/cqm-reportingTiming|2.0.0': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:group) &gt;= 1">group: minimum cardinality of 'group' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:Measure/f:group</sch:title>
    <sch:rule context="f:Measure/f:group">
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/5.0/StructureDefinition/extension-Measure.group.linkId']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/5.0/StructureDefinition/extension-Measure.group.linkId': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/uv/cqm/StructureDefinition/cqm-populationBasis|2.0.0']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/uv/cqm/StructureDefinition/cqm-populationBasis|2.0.0': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/uv/cqm/StructureDefinition/cqm-scoring|2.0.0']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/uv/cqm/StructureDefinition/cqm-scoring|2.0.0': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/uv/cqm/StructureDefinition/cqm-scoringUnit|2.0.0']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/uv/cqm/StructureDefinition/cqm-scoringUnit|2.0.0': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/uv/cqm/StructureDefinition/cqm-scoringPrecision|2.0.0']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/uv/cqm/StructureDefinition/cqm-scoringPrecision|2.0.0': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/uv/cqm/StructureDefinition/cqm-compositeScoring|2.0.0']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/uv/cqm/StructureDefinition/cqm-compositeScoring|2.0.0': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/uv/cqm/StructureDefinition/cqm-riskAdjustment|2.0.0']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/uv/cqm/StructureDefinition/cqm-riskAdjustment|2.0.0': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/uv/cqm/StructureDefinition/cqm-rateAggregation|2.0.0']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/uv/cqm/StructureDefinition/cqm-rateAggregation|2.0.0': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/uv/cqm/StructureDefinition/cqm-improvementNotation|2.0.0']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/uv/cqm/StructureDefinition/cqm-improvementNotation|2.0.0': maximum cardinality of 'extension' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:Measure/f:group/f:population</sch:title>
    <sch:rule context="f:Measure/f:group/f:population">
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/5.0/StructureDefinition/extension-Measure.group.population.linkId']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/5.0/StructureDefinition/extension-Measure.group.population.linkId': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/StructureDefinition/cqf-supportingEvidenceDefinition|5.3.0']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/StructureDefinition/cqf-supportingEvidenceDefinition|5.3.0': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/5.0/StructureDefinition/extension-Measure.group.population.linkId']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/5.0/StructureDefinition/extension-Measure.group.population.linkId': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/StructureDefinition/cqf-supportingEvidenceDefinition|5.3.0']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/StructureDefinition/cqf-supportingEvidenceDefinition|5.3.0': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:code) &gt;= 1">code: minimum cardinality of 'code' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:Measure/f:group/f:stratifier</sch:title>
    <sch:rule context="f:Measure/f:group/f:stratifier">
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/5.0/StructureDefinition/extension-Measure.group.stratifier.linkId']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/5.0/StructureDefinition/extension-Measure.group.stratifier.linkId': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/uv/cqm/StructureDefinition/cqm-valueSet|2.0.0']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/uv/cqm/StructureDefinition/cqm-valueSet|2.0.0': maximum cardinality of 'extension' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:Measure/f:group/f:stratifier/f:component</sch:title>
    <sch:rule context="f:Measure/f:group/f:stratifier/f:component">
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/5.0/StructureDefinition/extension-Measure.group.stratifier.component.linkId']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/5.0/StructureDefinition/extension-Measure.group.stratifier.component.linkId': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/uv/cqm/StructureDefinition/cqm-valueSet|2.0.0']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/uv/cqm/StructureDefinition/cqm-valueSet|2.0.0': maximum cardinality of 'extension' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:Measure/f:supplementalData</sch:title>
    <sch:rule context="f:Measure/f:supplementalData">
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/5.0/StructureDefinition/extension-Measure.supplementalData.linkId']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/5.0/StructureDefinition/extension-Measure.supplementalData.linkId': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/uv/cqm/StructureDefinition/cqm-valueSet|2.0.0']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/uv/cqm/StructureDefinition/cqm-valueSet|2.0.0': maximum cardinality of 'extension' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
</sch:schema>
